/**
 * 
 */
/**
 * @author ASUS
 *
 */
module Day5 {
}