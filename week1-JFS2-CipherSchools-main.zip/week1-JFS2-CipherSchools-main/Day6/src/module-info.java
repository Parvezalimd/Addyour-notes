/**
 * 
 */
/**
 * @author ASUS
 *
 */
module Day6 {
}