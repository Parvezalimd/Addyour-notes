package Day2;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char ch = 'A';  //65
		
		while(ch<=90) {
			System.out.print(ch+" ");
			ch++;
		}
		
		
		// do-while loop
		
		char ch1 = 'A';
		do {
			System.out.print(ch+" ");
			ch++;
		} while(ch<=90);

	}

}
