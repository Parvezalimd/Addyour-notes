/**
 * 
 */
/**
 * @author ASUS
 *
 */
module CipherSchool {
}